package com.kevin.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var porcupine: PorcupineManager? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = mutableListOf<Pair<String, String>>()

    private val utt = object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { main.post { if (id == "listen") listen() else resume() } }
        @Deprecated("Deprecated in Java")
        override fun onError(id: String?) { main.post { resume() } }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("JARVIS")
            .setContentText("Escuchando. Diga «Jarvis»").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("es", "ES")
                tts?.setOnUtteranceProgressListener(utt)
                startWake()
            }
        }
    }

    private fun startWake() {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("pico", "") ?: ""
        try {
            porcupine = PorcupineManager.Builder().setAccessKey(key).setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(applicationContext, PorcupineManagerCallback { main.post { onWake() } })
            porcupine?.start()
            speak("Jarvis en línea, señor.", "resume")
        } catch (e: Exception) {
            speak("No pude iniciar. Revise la clave de Picovoice, señor.", "none")
        }
    }

    private fun onWake() { try { porcupine?.stop() } catch (_: Exception) {}; speak("Dígame, señor.", "listen") }
    private fun resume() { try { porcupine?.start() } catch (_: Exception) {} }
    private fun speak(t: String, id: String) { tts?.speak(t.take(600), TextToSpeech.QUEUE_FLUSH, null, id) }
    private fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "").trim()

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { speak("No hay reconocimiento de voz, señor.", "resume"); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) resume() else handle(t)
            }
            override fun onError(e: Int) { resume() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES"))
    }

    private fun go(i: Intent) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    private fun handle(raw: String) {
        val t = norm(raw)
        if ("linterna" in t) {
            try {
                val cm = getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList[0], "apaga" !in t)
                speak(if ("apaga" in t) "Linterna apagada, señor." else "Linterna encendida, señor.", "resume")
            } catch (e: Exception) { speak("No pude usar la linterna, señor.", "resume") }
            return
        }
        Regex("alarma.*?(\\d{1,2})(?::(\\d{2})| y media| y cuarto)?\\s*(de la tarde|de la noche|pm)?").find(t)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = if (m.groupValues[2].isNotEmpty()) m.groupValues[2].toInt() else if (" y media" in m.value) 30 else if (" y cuarto" in m.value) 15 else 0
            if (m.groupValues[3].isNotEmpty() && h < 12) h += 12
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            val mm = "%02d".format(mi)
            speak("Alarma lista para las $h:$mm, señor.", "resume"); return
        }
        Regex("temporizador.*?(\\d+)\\s*(hora|minuto|segundo)").find(t)?.let { m ->
            val n = m.groupValues[1].toInt()
            val sec = n * when (m.groupValues[2]) { "hora" -> 3600; "minuto" -> 60; else -> 1 }
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            speak("Temporizador de $n ${m.groupValues[2]}, señor. Yo le aviso.", "resume"); return
        }
        if ("que hora" in t) { speak("Son las " + SimpleDateFormat("H:mm", Locale("es", "ES")).format(Date()) + ", señor.", "resume"); return }
        if (t.startsWith("abre ") || t.startsWith("abrir ")) {
            val name = t.substringAfter(" ").removePrefix("la aplicacion ").removePrefix("la app ").trim()
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val a = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == name }
                ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(name) }
            val li = a?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (li != null) { go(li); speak("Abriendo $name, señor.", "resume") } else speak("No encontré $name, señor.", "resume")
            return
        }
        if ("quien me escribio" in t || "mensajes" in t || "correos" in t) {
            val l = NotifService.items.take(3)
            speak(if (l.isEmpty()) "No tiene mensajes nuevos, señor." else l.joinToString(". ") { "En ${it.first}, ${it.second}: ${it.third}" }, "resume")
            return
        }
        Thread {
            val a = try { ask(raw) } catch (e: Exception) { "No tengo conexión, señor." }
            main.post { history.add("user" to raw); history.add("assistant" to a); speak(a, "resume") }
        }.start()
    }

    private fun ask(q: String): String {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("groq", "") ?: ""
        if (key.isEmpty()) return "Falta la clave de Groq, señor."
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content",
            "Eres JARVIS, el mayordomo personal de Kevin. Trátalo de señor, tono formal, 1 o 2 frases, en español."))
        history.takeLast(6).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject().put("model", "llama-3.3-70b-versatile").put("messages", msgs)
        val c = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 20000
        c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return "El servidor respondió con error, señor."
        val txt = c.inputStream.bufferedReader().readText()
        return JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }

    override fun onDestroy() {
        try { porcupine?.stop(); porcupine?.delete() } catch (_: Exception) {}
        recognizer?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
