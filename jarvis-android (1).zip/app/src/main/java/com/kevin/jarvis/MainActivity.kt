package com.kevin.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("j", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 40); setBackgroundColor(0xFF020814.toInt())
        }
        fun tv(t: String) = TextView(this).apply { text = t; setTextColor(0xFF00F0FF.toInt()); textSize = 15f; setPadding(0, 24, 0, 4) }
        fun et(h: String, v: String) = EditText(this).apply {
            hint = h; setText(v); setTextColor(Color.WHITE); setHintTextColor(0xFF7F9BB8.toInt()); setSingleLine()
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val pico = et("Clave de Picovoice", p.getString("pico", "") ?: "")
        val groq = et("Clave de Groq (gsk_...)", p.getString("groq", "") ?: "")
        root.addView(tv("J.A.R.V.I.S."))
        root.addView(pico); root.addView(groq)
        root.addView(btn("1. Guardar claves") {
            p.edit().putString("pico", pico.text.toString().trim()).putString("groq", groq.text.toString().trim()).apply()
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("2. Permiso micrófono y avisos") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(btn("3. Mostrar sobre otras apps (abrir apps)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("4. Acceso a notificaciones (WhatsApp/Gmail)") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        root.addView(btn("5. Batería: sin restricciones") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(btn("INICIAR JARVIS") { startForegroundService(Intent(this, JarvisService::class.java)) })
        root.addView(btn("DETENER") { stopService(Intent(this, JarvisService::class.java)) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
