package com.kevin.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = sbn.packageName
        if (p != "com.whatsapp" && p != "com.whatsapp.w4b" && p != "com.google.android.gm") return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: return
        val text = e.getCharSequence("android.text")?.toString() ?: return
        if (title == "WhatsApp" || title == "WhatsApp Business") return
        val app = when (p) { "com.google.android.gm" -> "Gmail"; "com.whatsapp.w4b" -> "WhatsApp Business"; else -> "WhatsApp" }
        items.add(0, Triple(app, title, text))
        while (items.size > 20) items.removeAt(items.size - 1)
    }
    companion object { val items = CopyOnWriteArrayList<Triple<String, String, String>>() }
}
